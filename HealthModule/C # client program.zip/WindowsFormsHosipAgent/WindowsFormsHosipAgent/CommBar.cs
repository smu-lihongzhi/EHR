﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsHosipAgent
{
    internal class CommBar
    {
        public SerialPort serialPort;

        //存储转换的数据值
        public string Code { get; set; }

        public CommBar()
        {
            serialPort = new SerialPort();
        }

        //串口状态
        public bool IsOpen
        {
            get
            {
                return serialPort.IsOpen;
            }
        }

        //打开串口
        public bool Open()
        {
            if (serialPort.IsOpen)
            {
                Close();
            }
            serialPort.Open();
            if (serialPort.IsOpen)
            {
                return true;
            }
            else
            {
                Console.WriteLine("串口打开失败！");
                return false;
            }
        }

        //关闭串口
        public void Close()
        {
            serialPort.Close();
        }

        //定入数据，这里没有用到
        public void WritePort(byte[] send, int offSet, int count)
        {
            if (IsOpen)
            {
                serialPort.Write(send, offSet, count);
            }
        }

        //获取可用串口
        public string[] GetComName()
        {
            string[] names = null;
            try
            {
                names = SerialPort.GetPortNames();
            }
            catch (Exception)
            {
                Console.WriteLine("找不到串口");
            }
            return names;
        }

        //注册一个串口
        public void SerialPortValue(string portName, int baudRate)
        {
            serialPort.PortName = portName;
            serialPort.BaudRate = baudRate;
            serialPort.DataBits = 8;
            serialPort.StopBits = System.IO.Ports.StopBits.One;
            serialPort.Parity = System.IO.Ports.Parity.None;
            serialPort.ReadTimeout = 100;
            //commBar.serialPort.WriteTimeout = -1;
        }
    }
}
