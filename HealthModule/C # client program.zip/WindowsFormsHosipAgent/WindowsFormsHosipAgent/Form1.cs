﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace WindowsFormsHosipAgent
{
    public partial class Form1 : Form
    {
        private CommBar commBar;
        private string sensorData = ""; //传感器数据
        private string commToken;       //验证的token

        public Form1()
        {
            
            obtainToken();
            Console.WriteLine("Form initing...");
            InitializeComponent();
            this.comboBox1.SelectedIndex = 2;
            commBar = new CommBar();
            RunCompareBarCode();
            initFormData();
        }
        public void RunCompareBarCode()
        { 
            try
            {
                string comPort = "COM3"; //需要根据设备连接串口
                commBar.SerialPortValue(comPort, 9600);
                if (commBar.Open())
                    commBar.serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_DataReceived);
            }
            catch (Exception ex)
            {
                commBar.Close();
            }
        }


        //串口连接并获取数据
        public void serialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(100);
            byte[] m_recvBytes = new byte[commBar.serialPort.BytesToRead];
            int result = commBar.serialPort.Read(m_recvBytes, 0, m_recvBytes.Length);
            if (result <= 0)
                return;
            commBar.Code = Encoding.ASCII.GetString(m_recvBytes, 0, m_recvBytes.Length);
            string codeTxt = commBar.Code;
            if (!string.IsNullOrEmpty(codeTxt) && codeTxt.Length >= 1&& !codeTxt.Contains("No"))
            {
                //codeTxt为获取串口传的数据
                Console.WriteLine(codeTxt);
                sensorData = codeTxt;
            }


            commBar.serialPort.DiscardInBuffer();
        }

        public void initFormData()
        {
            this.textBox1.Text = "Hongzhi Li";
            this.textBox2.Text = "35";
            this.textBox3.Text = "23455555";
            this.textBox4.Text = "Teacher";
            this.textBox5.Text = "An Hui, Chizhou";
            this.richTextBox1.Text = "xxxxxxxxx";
            ////////////////////////////////////////
            while (sensorData.Equals(""))
            {
              ;
            }
            if (!sensorData.Equals(""))
            {

                string[] ret = sensorData.Split('_');  //真实的传感器数据
                this.textBox7.Text = ret[0];
                this.textBox6.Text = ret[1];
                this.textBox8.Text = "110";  //传感器有限
                this.textBox9.Text = "36.5";
            }
            DateTime today = DateTime.Today;
            this.richTextBox2.Text = today.ToString()+"COM3 Connecting ....";
            this.richTextBox2.AppendText("\n Token:" + this.commToken);
        }

       
        public void obtainToken()
        {
            string name = Dns.GetHostName();
            IPAddress[] ipadrlist = Dns.GetHostAddresses(name);
            string key = ipadrlist[0].ToString();
            string serviceAddress = "http://127.0.0.1:8085/getToken?key=" + key; 
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceAddress);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            Console.WriteLine(retString);
            this.commToken = retString;
            //Response.Write(retString);
        }


        public void sendEMCReq(string heart_rate, string blood_press, string pulse)
        {
            string serviceAddress = "http://127.0.0.1:8085/writeEMC?heart_rate="+heart_rate+ "&pulse="+pulse+ "&token="+commToken+ "&blood_press="+ blood_press;

            serviceAddress = Regex.Replace(serviceAddress, @"[\r\n]", "");
            Console.WriteLine(serviceAddress);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceAddress.ToString());
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            Console.WriteLine(retString);
           
            if (!retString.Equals(""))
            {
                Form2 fm2 = new Form2(retString);
                fm2.Show();
            }
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string heart_rate = this.textBox6.Text;
            string pulse = this.textBox7.Text;
            string blood_press = this.textBox8.Text;

            sendEMCReq(heart_rate, blood_press, pulse);
        }
    }


}
