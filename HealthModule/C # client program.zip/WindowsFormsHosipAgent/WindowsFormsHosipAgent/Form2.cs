﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsHosipAgent
{
    public partial class Form2 : Form
    {
        private string fileId;


        public Form2(string fileId)
        {
            InitializeComponent();
            this.fileId = fileId;
            this.textBox1.Text = fileId;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.comboBox1.Text.Equals(""))
            {
                MessageBox.Show("Role cannot be empty!");
                return;
            }
            //Console.WriteLine(this.comboBox1.SelectedIndex); //打印选项
            string selected_ret="";
            switch (this.comboBox1.SelectedIndex)
            {
                case 0: selected_ret = ";d_"; break;
                case 1: selected_ret = ";p_"; break;
                case 2: selected_ret = ";a_"; break;

            }
            if (this.radioButton1.Checked)
            {
                selected_ret = selected_ret + "1";
            }
            else
            {
                selected_ret = selected_ret + "0";
            }
            if (this.radioButton3.Checked)
            {
                selected_ret = selected_ret + "_1";
            }
            else
            {
                selected_ret = selected_ret + "_0";
            }
            if (this.radioButton5.Checked)
            {
                selected_ret = selected_ret + "_1";
            }
            else
            {
                selected_ret = selected_ret + "_0";
            }
             this.richTextBox1.AppendText (selected_ret);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ret_str = this.richTextBox1.Text.ToString();
            string[] ret_Arr = ret_str.Split(';');
            string d_r="";
            string p_r="";
            string a_r="";
            string fileId = this.textBox1.Text.ToString();
            foreach (string str in ret_Arr)
            {
                //Console.WriteLine(str);
                if (str.Contains("d_"))
                {
                    d_r = str.Remove(0, 2);
                    Console.WriteLine(d_r);
                }
                if (str.Contains("p_"))
                {
                    p_r = str.Remove(0, 2);
                    Console.WriteLine(p_r);
                }
                if (str.Contains("a_"))
                {
                    a_r = str.Remove(0, 2);
                    Console.WriteLine(a_r);
                }

            }

            //调用云服务器接口写入文件的权限控制信息
            string serviceAddress = "http://127.0.0.1:8085/writeEMCRights?d_r=" +d_r+ "&p_r=" + p_r + "&a_r=" + a_r + "&fileId=" + fileId;

            serviceAddress = Regex.Replace(serviceAddress, @"[\r\n]", "");
            Console.WriteLine(serviceAddress);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceAddress.ToString());
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            Console.WriteLine(retString);
            if (!retString.Equals(""))  //调用服务接口同步访问控制列表至区块链
            {
                serviceAddress = "http://127.0.0.1:8080/sendAcl?fileId=" + fileId;
                serviceAddress = Regex.Replace(serviceAddress, @"[\r\n]", "");
                Console.WriteLine(serviceAddress);
                request = (HttpWebRequest)WebRequest.Create(serviceAddress.ToString());
                request.Method = "GET";
                request.ContentType = "text/html;charset=UTF-8";
                response = (HttpWebResponse)request.GetResponse();
                myResponseStream = response.GetResponseStream();
                myStreamReader = new StreamReader(myResponseStream, Encoding.UTF8);
                retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();
                Console.WriteLine(retString);
                MessageBox.Show("Set File Rights Success!");
            }

        }
    }
}
